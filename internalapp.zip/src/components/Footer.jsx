import React from "react";

export const Footer = () => {
  return (
    <>
      <div className="footer">
        <p>About</p>
        <p>Support</p>
        <p>Terms & Condition</p>
      </div>
    </>
  );
};
